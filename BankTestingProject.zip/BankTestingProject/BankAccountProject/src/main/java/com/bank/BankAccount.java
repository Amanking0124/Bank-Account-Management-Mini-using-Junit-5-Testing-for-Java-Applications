package com.bank;

public class BankAccount {
    private String owner;
    private int balance;

    public BankAccount() {
        this.owner = "";
        this.balance = 0;
    }

    public BankAccount(String owner, int balance) {
        this.owner = owner;
        this.balance = balance;
    }

    public void deposit(int amount) {
        balance += amount;
    }

    public void withdraw(int amount) {
        balance -= amount;
    }

    public int getBalance() {
        return balance;
    }

    public void transfer(BankAccount other, int amount) {
        this.withdraw(amount);
        other.deposit(amount);
    }

    public int calculateInterest(int rate, int years) {
        return balance * rate * years / 100;
    }
}
