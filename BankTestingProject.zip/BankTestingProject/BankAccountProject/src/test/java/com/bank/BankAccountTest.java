package com.bank;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class BankAccountTest {

    @Test
    void testDepositAndGetBalance() {
        BankAccount account = new BankAccount("Amandeep", 5000);
        account.deposit(2000);
        assertEquals(7000, account.getBalance(), "Deposit failed");
    }

    @Test
    void testWithdraw() {
        BankAccount account = new BankAccount("Amandeep", 5000);
        account.withdraw(1500);
        assertEquals(3500, account.getBalance(), "Withdraw failed");
    }

    @Test
    void testTransfer() {
        BankAccount account1 = new BankAccount("Amandeep", 5000);
        BankAccount account2 = new BankAccount("Another", 3000);

        account1.transfer(account2, 2000);

        assertEquals(3000, account1.getBalance(), "Transfer from account1 failed");
        assertEquals(5000, account2.getBalance(), "Transfer to account2 failed");
    }

    @Test
    void testCalculateInterest() {
        BankAccount account = new BankAccount("Amandeep", 5000);
        int interest = account.calculateInterest(5, 2); // 5% for 2 years
        assertEquals(500, interest, "Interest calculation failed");
    }
}
